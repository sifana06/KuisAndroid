package com.cips.siswa;

public class Konfigurasi {
    public static final String URL_ADD = "http://192.168.56.1/siswa/tambahSiswa.php";
    public static final String URL_GET_ALL = "http://192.168.56.1/siswa/tampilSiswa.php";
    public static final String URL_GET_EMP = "http://192.168.56.1/siswa/editSiswa.php";
    public static final String URL_DELETE_EMP = "http://192.168.56.1/siswa/hapus.php";
    public static String URL_UPDATE_EMP= "http://192.168.56.1/siswa/update.php";

    //catatan : hapus mahasiswa harus mengganti nomor id di belakang hapusMhs.php

    public static final String KEY_SYR_NIS = "nis";
    public static final String KEY_SYR_NAMA = "nama";
    public static final String KEY_SYR_ALAMAT = "alamat";


    public static final String TAG_JSON_ARRAY = "result";
    public static final String TAG_NIS = "nis";
    public static final String TAG_NAMA = "nama";
    public static final String TAG_ALAMAT = "alamat";

    public static final String SYR_NIS = "mhs_nis";

}
